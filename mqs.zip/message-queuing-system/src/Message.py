from typing import Dict
import json

class Message:
    def __init__(self, content: Dict):
        self.content = json.dumps(content)

    def get_content(self) -> Dict:
        return json.loads(self.content)