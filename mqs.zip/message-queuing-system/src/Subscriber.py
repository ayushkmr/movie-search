from Queue import Queue
from Message import Message
from typing import Callable

class Subscriber:

    def __init__(self, queue: Queue):
        self.queue = queue

    def subscribe(self, callback: Callable[[Message], None]) -> None:
        self.queue.subscribe(callback)