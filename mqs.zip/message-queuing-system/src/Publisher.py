from typing import List
from Queue import Queue
from Message import Message

class Publisher:
    def __init__(self):
        self.queues: List[Queue] = []

    def add_queue(self, queue: Queue) -> None:
        self.queues.append(queue)

    def remove_queue(self, queue: Queue) -> None:
        if queue in self.queues:
            self.queues.remove(queue)

    def publish(self, message: Message) -> None:
        for queue in self.queues:
            queue.enqueue(message)