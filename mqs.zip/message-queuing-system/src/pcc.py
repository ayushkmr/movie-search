from multiprocessing import Process

def print_numbers():
    for i in range(10):
        print(i)

process1 = Process(target=print_numbers)
# process2 = Process(target=print_numbers)

process1.start()


process1.join()

