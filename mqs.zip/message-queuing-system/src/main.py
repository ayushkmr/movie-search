import logging
from QueueManager import QueueManager
from Publisher import Publisher
from Subscriber import Subscriber
from Message import Message

# Configure logging
logging.basicConfig(level=logging.INFO)

def api_callback(endpoint: str):
    def callback(message: Message):
        logging.info(f"Sending message to 111 {endpoint}: {message.get_content()}")
        # Simulate API call
        # response = requests.post(endpoint, json=message.get_content())
        # response.raise_for_status()
    return callback

def main():
    logging.info("Initializing QueueManager")
    # Initialize QueueManager
    queue_manager = QueueManager()

    logging.info("Creating queues")
    # Create queues
    queue1 = queue_manager.create_queue("queue1")
    queue2 = queue_manager.create_queue("queue2")

    logging.info("Initializing Publisher and adding queues")
    # Initialize Publisher and add queues
    publisher = Publisher()
    publisher.add_queue(queue1)
    publisher.add_queue(queue2)

    logging.info("Initializing Subscribers and registering callbacks")
    # Initialize Subscribers and register callbacks
    subscriber1 = Subscriber(queue1)
    subscriber2 = Subscriber(queue2)

    subscriber1.subscribe(api_callback("http://api1.example.com/webhook"))
    subscriber2.subscribe(api_callback("http://api2.example.com/webhook"))

    logging.info("Publishing messages")
    # Publish messages
    message1 = Message({"message": "Hello, Queue 1!"})
    message2 = Message({"message": "Hello, Queue 2!"})

    publisher.publish(message1)
    publisher.publish(message2)

    logging.info("Waiting for messages")
    # Start listening for messages

if __name__ == "__main__":
    main()