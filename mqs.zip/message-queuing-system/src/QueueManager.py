from Queue import Queue

class QueueManager:
    def __init__(self):
        self.queues = {}

    def create_queue(self, name: str) -> Queue:
        if name in self.queues:
            raise ValueError(f"Queue with name {name} already exists")
        queue = Queue(name)
        self.queues[name] = queue
        return queue
    
    def remove_queue(self, name: str) -> None:
        if name in self.queues:
            del self.queues[name]

    def get_queue(self, name: str) -> Queue:
        return self.queues[name]