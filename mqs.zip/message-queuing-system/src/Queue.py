import logging

from typing import List, Optional, Callable
from Message import Message
from multiprocessing import Process

class Queue:
    def __init__(self, name: str):
        self.name = name
        self.messages: List[Message] = []
        self.subscribers: List[Callable[[Message], None]] = []

    def enqueue(self, message: Message) -> None:
        self.messages.append(message)
        process1 = Process(target=self.notify_subscribers, args=(message,))
        process1.start()
        process1.join()
        logging.info(f'Message enqueued: {message}')

    def dequeue(self) -> Optional[Message]:
        if self.messages:
            dequeued_message = self.messages.pop(0)
            logging.info(f'Message dequeued: {dequeued_message}')
            return dequeued_message
        return None

    def subscribe(self, callback: Callable[[Message], None]) -> None:
        self.subscribers.append(callback)


    def notify_subscribers(self, message: Message) -> None:
        for subscriber in self.subscribers:
            subscriber(message)